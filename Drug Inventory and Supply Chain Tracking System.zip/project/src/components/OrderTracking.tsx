import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  Truck,
  Check,
  Clock,
  MapPin,
  Calendar,
  CreditCard
} from 'lucide-react';

const OrderTracking: React.FC = () => {
  const { orders } = useApp();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'shipped':
        return 'bg-blue-100 text-blue-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered':
        return Check;
      case 'shipped':
        return Truck;
      case 'processing':
        return Package;
      default:
        return Clock;
    }
  };

  const getTrackingSteps = (status: string) => {
    const steps = [
      { name: 'Order Placed', status: 'completed' },
      { name: 'Processing', status: status === 'pending' ? 'current' : 'completed' },
      { name: 'Shipped', status: status === 'shipped' ? 'current' : status === 'delivered' ? 'completed' : 'pending' },
      { name: 'Delivered', status: status === 'delivered' ? 'completed' : 'pending' }
    ];
    return steps;
  };

  if (orders.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Order Tracking</h1>
          <p className="text-sm text-gray-600">Track your orders and delivery status</p>
        </div>
        
        <div className="text-center py-12">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
          <p className="text-gray-600">You haven't placed any orders yet.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Order Tracking</h1>
        <p className="text-sm text-gray-600">Track your orders and delivery status</p>
      </div>

      {/* Orders List */}
      <div className="space-y-6">
        {orders.map((order) => {
          const StatusIcon = getStatusIcon(order.status);
          const trackingSteps = getTrackingSteps(order.status);
          
          return (
            <div key={order.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              {/* Order Header */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Order #{order.id}</h3>
                    <p className="text-sm text-gray-600">
                      Placed on {new Date(order.orderDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                      <StatusIcon className="w-4 h-4 mr-1" />
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                    <p className="text-lg font-bold text-gray-900 mt-1">${order.total.toFixed(2)}</p>
                  </div>
                </div>

                {/* Tracking Number */}
                {order.trackingNumber && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-blue-800">Tracking Number</span>
                      <span className="text-sm font-mono text-blue-600">{order.trackingNumber}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Tracking Steps */}
              <div className="p-6">
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-4">Tracking Progress</h4>
                  <div className="flex items-center justify-between">
                    {trackingSteps.map((step, index) => (
                      <div key={step.name} className="flex flex-col items-center flex-1">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          step.status === 'completed'
                            ? 'bg-green-500 text-white'
                            : step.status === 'current'
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-200 text-gray-500'
                        }`}>
                          {step.status === 'completed' ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <span className="text-xs font-medium">{index + 1}</span>
                          )}
                        </div>
                        <span className={`text-xs mt-2 text-center ${
                          step.status === 'completed' || step.status === 'current'
                            ? 'text-gray-900 font-medium'
                            : 'text-gray-500'
                        }`}>
                          {step.name}
                        </span>
                        {index < trackingSteps.length - 1 && (
                          <div className={`absolute top-4 w-full h-0.5 ${
                            step.status === 'completed' ? 'bg-green-500' : 'bg-gray-200'
                          }`}
                          style={{ left: '50%', width: 'calc(100% - 2rem)', marginLeft: '1rem' }} />
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Delivery Info */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Delivery Address</h4>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-start space-x-2">
                        <MapPin className="w-4 h-4 mt-0.5 text-gray-400" />
                        <div>
                          <p>{order.address.street}</p>
                          <p>{order.address.city}, {order.address.state} {order.address.zipCode}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment Info */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Payment Method</h4>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <CreditCard className="w-4 h-4 text-gray-400" />
                        <span>{order.paymentMethod.name} •••• {order.paymentMethod.details.slice(-4)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Delivery Date */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Estimated Delivery</h4>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span>{new Date(order.estimatedDelivery).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Order Items */}
                <div className="mt-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Order Items</h4>
                  <div className="space-y-3">
                    {order.items.map((item) => (
                      <div key={item.drug.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <img
                          src={item.drug.image}
                          alt={item.drug.name}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">{item.drug.name}</p>
                          <p className="text-sm text-gray-600">{item.drug.manufacturer}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-gray-900">Qty: {item.quantity}</p>
                          <p className="text-sm text-gray-600">${(item.drug.price * item.quantity).toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default OrderTracking;