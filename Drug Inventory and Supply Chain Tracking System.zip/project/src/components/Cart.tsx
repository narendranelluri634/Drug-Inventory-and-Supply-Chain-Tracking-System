import React from 'react';
import { useApp } from '../context/AppContext';
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Heart,
  Package
} from 'lucide-react';

interface CartProps {
  onPageChange: (page: string) => void;
}

const Cart: React.FC<CartProps> = ({ onPageChange }) => {
  const { cart, updateCartQuantity, removeFromCart, addToWishlist, drugs } = useApp();

  const total = cart.reduce((sum, item) => sum + (item.drug.price * item.quantity), 0);

  const handleQuantityChange = (drugId: string, change: number) => {
    const currentItem = cart.find(item => item.drug.id === drugId);
    if (currentItem) {
      updateCartQuantity(drugId, currentItem.quantity + change);
    }
  };

  const handleMoveToWishlist = (drug: any) => {
    addToWishlist(drug);
    removeFromCart(drug.id);
  };

  if (cart.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Shopping Cart</h1>
          <p className="text-sm text-gray-600">Your cart is currently empty</p>
        </div>
        
        <div className="text-center py-12">
          <ShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Your cart is empty</h3>
          <p className="text-gray-600 mb-6">Start shopping to add items to your cart.</p>
          <button
            onClick={() => onPageChange('inventory')}
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Package className="w-4 h-4 mr-2" />
            Browse Inventory
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Shopping Cart</h1>
        <p className="text-sm text-gray-600">{cart.length} items in your cart</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <div key={item.drug.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-start space-x-4">
                <img
                  src={item.drug.image}
                  alt={item.drug.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-semibold text-gray-900">{item.drug.name}</h3>
                  <p className="text-sm text-gray-600">{item.drug.manufacturer}</p>
                  <p className="text-sm text-gray-500 mt-1">{item.drug.category}</p>
                  <div className="flex items-center mt-2">
                    <span className="text-lg font-bold text-blue-600">${item.drug.price}</span>
                    <span className="text-sm text-gray-500 ml-2">per unit</span>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleQuantityChange(item.drug.id, -1)}
                      className="p-1 rounded-full hover:bg-gray-100 transition-colors"
                      disabled={item.quantity <= 1}
                    >
                      <Minus className="w-4 h-4 text-gray-600" />
                    </button>
                    <span className="w-12 text-center font-medium">{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item.drug.id, 1)}
                      className="p-1 rounded-full hover:bg-gray-100 transition-colors"
                      disabled={item.quantity >= item.drug.stock}
                    >
                      <Plus className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-gray-900">
                      ${(item.drug.price * item.quantity).toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {item.drug.stock - item.quantity} left in stock
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between pt-4 border-t border-gray-200">
                <button
                  onClick={() => handleMoveToWishlist(item.drug)}
                  className="inline-flex items-center text-sm text-gray-600 hover:text-red-600 transition-colors"
                >
                  <Heart className="w-4 h-4 mr-1" />
                  Move to Wishlist
                </button>
                <button
                  onClick={() => removeFromCart(item.drug.id)}
                  className="inline-flex items-center text-sm text-red-600 hover:text-red-700 transition-colors"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal ({cart.length} items)</span>
                <span className="font-medium">${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Shipping</span>
                <span className="font-medium">$5.99</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax</span>
                <span className="font-medium">${(total * 0.08).toFixed(2)}</span>
              </div>
              <div className="border-t border-gray-200 pt-3">
                <div className="flex justify-between">
                  <span className="text-lg font-semibold text-gray-900">Total</span>
                  <span className="text-lg font-bold text-blue-600">
                    ${(total + 5.99 + (total * 0.08)).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onPageChange('checkout')}
              className="w-full mt-6 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              Proceed to Checkout
            </button>

            <button
              onClick={() => onPageChange('inventory')}
              className="w-full mt-3 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors text-sm"
            >
              Continue Shopping
            </button>
          </div>

          {/* Recommended Items */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">You might also like</h3>
            <div className="space-y-3">
              {drugs.slice(0, 2).map((drug) => (
                <div key={drug.id} className="flex items-center space-x-3">
                  <img
                    src={drug.image}
                    alt={drug.name}
                    className="w-12 h-12 object-cover rounded-lg"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{drug.name}</p>
                    <p className="text-sm text-blue-600 font-medium">${drug.price}</p>
                  </div>
                  <button className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 transition-colors">
                    Add
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;