import React, { createContext, useContext, useState } from 'react';
import { Drug, CartItem, Address, PaymentMethod, Order } from '../types';

interface AppContextType {
  drugs: Drug[];
  cart: CartItem[];
  wishlist: Drug[];
  addresses: Address[];
  paymentMethods: PaymentMethod[];
  orders: Order[];
  addDrug: (drug: Omit<Drug, 'id'>) => void;
  updateDrug: (id: string, drug: Partial<Drug>) => void;
  deleteDrug: (id: string) => void;
  addToCart: (drug: Drug, quantity: number) => void;
  removeFromCart: (drugId: string) => void;
  updateCartQuantity: (drugId: string, quantity: number) => void;
  addToWishlist: (drug: Drug) => void;
  removeFromWishlist: (drugId: string) => void;
  addAddress: (address: Omit<Address, 'id'>) => void;
  addPaymentMethod: (method: Omit<PaymentMethod, 'id'>) => void;
  createOrder: (order: Omit<Order, 'id' | 'orderDate'>) => void;
  clearCart: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock data
const mockDrugs: Drug[] = [
  {
    id: '1',
    name: 'Aspirin 100mg',
    manufacturer: 'Bayer',
    category: 'Pain Relief',
    price: 12.99,
    stock: 500,
    description: 'Low-dose aspirin for cardiovascular protection',
    expiryDate: '2025-12-31',
    batchNumber: 'ASP001',
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300',
    isActive: true
  },
  {
    id: '2',
    name: 'Amoxicillin 500mg',
    manufacturer: 'Pfizer',
    category: 'Antibiotics',
    price: 24.50,
    stock: 200,
    description: 'Broad-spectrum antibiotic for bacterial infections',
    expiryDate: '2025-10-15',
    batchNumber: 'AMX002',
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300',
    isActive: true
  },
  {
    id: '3',
    name: 'Metformin 850mg',
    manufacturer: 'Novartis',
    category: 'Diabetes',
    price: 18.75,
    stock: 350,
    description: 'Type 2 diabetes management medication',
    expiryDate: '2025-08-20',
    batchNumber: 'MET003',
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300',
    isActive: true
  }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [drugs, setDrugs] = useState<Drug[]>(mockDrugs);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Drug[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const addDrug = (drugData: Omit<Drug, 'id'>) => {
    const newDrug: Drug = {
      ...drugData,
      id: Date.now().toString()
    };
    setDrugs(prev => [...prev, newDrug]);
  };

  const updateDrug = (id: string, drugData: Partial<Drug>) => {
    setDrugs(prev => prev.map(drug => 
      drug.id === id ? { ...drug, ...drugData } : drug
    ));
  };

  const deleteDrug = (id: string) => {
    setDrugs(prev => prev.filter(drug => drug.id !== id));
    setCart(prev => prev.filter(item => item.drug.id !== id));
    setWishlist(prev => prev.filter(drug => drug.id !== id));
  };

  const addToCart = (drug: Drug, quantity: number) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.drug.id === drug.id);
      if (existingItem) {
        return prev.map(item =>
          item.drug.id === drug.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { drug, quantity }];
    });
  };

  const removeFromCart = (drugId: string) => {
    setCart(prev => prev.filter(item => item.drug.id !== drugId));
  };

  const updateCartQuantity = (drugId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(drugId);
      return;
    }
    setCart(prev => prev.map(item =>
      item.drug.id === drugId ? { ...item, quantity } : item
    ));
  };

  const addToWishlist = (drug: Drug) => {
    setWishlist(prev => {
      if (prev.find(item => item.id === drug.id)) return prev;
      return [...prev, drug];
    });
  };

  const removeFromWishlist = (drugId: string) => {
    setWishlist(prev => prev.filter(drug => drug.id !== drugId));
  };

  const addAddress = (addressData: Omit<Address, 'id'>) => {
    const newAddress: Address = {
      ...addressData,
      id: Date.now().toString()
    };
    setAddresses(prev => [...prev, newAddress]);
  };

  const addPaymentMethod = (methodData: Omit<PaymentMethod, 'id'>) => {
    const newMethod: PaymentMethod = {
      ...methodData,
      id: Date.now().toString()
    };
    setPaymentMethods(prev => [...prev, newMethod]);
  };

  const createOrder = (orderData: Omit<Order, 'id' | 'orderDate'>) => {
    const newOrder: Order = {
      ...orderData,
      id: Date.now().toString(),
      orderDate: new Date().toISOString()
    };
    setOrders(prev => [...prev, newOrder]);
  };

  const clearCart = () => {
    setCart([]);
  };

  return (
    <AppContext.Provider value={{
      drugs,
      cart,
      wishlist,
      addresses,
      paymentMethods,
      orders,
      addDrug,
      updateDrug,
      deleteDrug,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      addToWishlist,
      removeFromWishlist,
      addAddress,
      addPaymentMethod,
      createOrder,
      clearCart
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};