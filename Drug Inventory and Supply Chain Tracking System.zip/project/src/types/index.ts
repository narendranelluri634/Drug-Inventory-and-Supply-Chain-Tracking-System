export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'pharmacist' | 'customer';
  avatar?: string;
}

export interface Drug {
  id: string;
  name: string;
  manufacturer: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  expiryDate: string;
  batchNumber: string;
  image: string;
  isActive: boolean;
}

export interface CartItem {
  drug: Drug;
  quantity: number;
}

export interface Address {
  id: string;
  type: 'home' | 'work' | 'other';
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  isDefault: boolean;
}

export interface PaymentMethod {
  id: string;
  type: 'credit' | 'debit' | 'paypal' | 'bank';
  name: string;
  details: string;
  isDefault: boolean;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  address: Address;
  paymentMethod: PaymentMethod;
  orderDate: string;
  estimatedDelivery: string;
  trackingNumber?: string;
}